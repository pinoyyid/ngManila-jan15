'use strict'

    
var restMethods = function($http){
    /*
    * HTTP POST a new To Do
    * @param title: string
    * @return promise: object
    */
     this.newTodo = function(title){
        var promise = $http.post(POST_URL, {
            'title': title
        });
        
        return promise;
        
    }
    
};


angular.module('ngtodoApp')
    .service('RestMethods', restMethods);
    
